import {request} from "./request";

export function getHomeData() {
  return request({
    url: '/Android-home-index.json',
  })
}
