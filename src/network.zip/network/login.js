import {request} from "./request";
import Qs from 'qs';
import store from 'store/index';

export function getLogin(phone,password,type) {
  let datas = {
    'phone':phone,
    'password':password,
    'type':type,
  }
  let headCode = type == 2 ? {
    url: 'Android-Login-Login.json',
    method: 'post',
    headers:{'X-Powered-Token-By':store.state.codeUs},
    data: Qs.stringify(datas)
  }: {
    url: 'Android-Login-Login.json',
    method: 'post',
    data: Qs.stringify(datas)
  }
  return request(headCode)
}
export function getCode(phone,type) {
  let data = {
    'phone':phone,
    'type':type
  }
  return request({
    url: 'Android-Login-sendcode.json',
    method: 'post',
    data: Qs.stringify(data),
  })
}

export function getReg(data) {
  return request({
    url: 'Android-Login-register.json',
    method: 'post',
    headers:{'X-Powered-Token-By':store.state.codeUs},
    data: Qs.stringify(data)
  })
}
