import {request} from "./request";

export function getLoanList(data) {
  let params  = {
    'productid':data.productid,
    'status':data.status,
    'page':data.page,
  }
  return request({
    url: '/Android-Loan-investment.json',
    method: 'get',
    params :params
  })
}
export function getLoanType() {
  return request({
    url: '/Android-Loan-condition.json',
    method: 'get',
  })
}
export function getLoanDetail_1(id) {
  return request({
    url: '/Android-Loan-loanDetail_1.json',
    method: 'get',
    params:{'id':id}
  })
}
export function getLoanDetail_2(id) {
  return request({
    url: '/Android-Loan-loanDetail_2.json',
    method: 'get',
    params:{'id':id}
  })
}
export function getLoanDetail_3(id) {
  return request({
    url: '/Android-Loan-loanDetail_3.json',
    method: 'get',
    params:{'id':id}
  })
}
export function getLoanDetail_4(id) {
  return request({
    url: '/Android-Loan-loanDetail_4.json',
    method: 'get',
    params:{'id':id}
  })
}
export function loanRepay(id) {
  return request({
    url: '/Android-Loan-loanRepay.json',
    method: 'get',
    params:{'id':id}
  })
}
export function investShow(id) {
  return request({
    url: '/Android-Loan-investShow.json',
    method: 'get',
    params:{'id':id}
  })
}investShow
