import {request} from "./request";

export function getAssList(data) {
  let params  = {
    'rate':data.rate,
    'status':data.status,
    'page':data.page,
  }
  return request({
    url: '/Android-Assignment-index.json',
    method: 'get',
    params :params
  })
}